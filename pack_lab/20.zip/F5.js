$('#F5').on('click', function(){
123
});
