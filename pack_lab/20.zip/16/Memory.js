$('#Memory').on('click', function(){
123123
});
