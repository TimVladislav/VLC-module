$('#sound').on('click', function(){
asd
});
